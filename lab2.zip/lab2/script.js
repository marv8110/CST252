console.log("hi there");

//Task 1
let box1 = document.querySelector("#box1");
console.log(box1);
box1.style.border = "thick solid pink";

//Task 2
let box2 = document.querySelector("#box2");
console.log(box2);
box2.textContent = "Hi there";

//Task 3
let box3 = document.querySelector("#box3");
console.log(box3);
box3.style.backgroundColor = "darkGreen";

//Task 4
let box4 = document.querySelector("#box4");
console.log(box4);
box4.style.color = "#c08ee5";

//Task 5
let box5 = document.querySelector("#box5");
console.log(box5);
box5.style.fontSize = "15px";

//Task 6
let boxImage = document.querySelector("#boxImage");
console.log(boxImage);
boxImage.src = "image2.png";